﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebDataTable.Models;

namespace WebDataTable.Controllers
{


    //https://datatables.net/forums/discussion/22874/child-row-hide-show-not-displaying

    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }



        [HttpGet("/Home/CarregaGrafico")]
        public JsonResult CarregaGrafico()
        {
            string[] chave = new string[400];


            for (int i = 0; i < 300; i++)
            {
                chave[i] = i.ToString();
            }


            var dados = new List<DadosModel>();
            for (int i = 0; i < 100; i++)
            {
                dados.Add(new DadosModel
                {
                    id = i.ToString(),
                    name = "Gomes Feio " + i.ToString(),
                    position = "System Architect",
                    salary = "$320,800",
                    start_date = "2011/04/25",
                    office = "Edinburgh",
                    extn = chave[i]

                });
            }

            for (int i = 100; i < 200; i++)
            {
                dados.Add(new DadosModel
                {
                    id = i.ToString(),
                    name = "Gomes Feio " + i.ToString(),
                    position = "System Architect",
                    salary = "$320,800",
                    start_date = "2011/04/25",
                    office = "Edinburgh",
                    extn = chave[i]

                });
            }


            return Json(new { dados = dados });
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

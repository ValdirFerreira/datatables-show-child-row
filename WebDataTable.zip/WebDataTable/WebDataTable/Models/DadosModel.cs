﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDataTable.Models
{
    public class DadosModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string position { get; set; }
        public string salary { get; set; }
        public string start_date { get; set; }
        public string office { get; set; }
        public string extn { get; set; }
 
    }
}
